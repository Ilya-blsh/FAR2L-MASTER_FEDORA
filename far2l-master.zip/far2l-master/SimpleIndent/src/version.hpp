#define PLUGIN_MAJOR 2
#define PLUGIN_MINOR 2
#define PLUGIN_DESC L"Indent selected block"
#define PLUGIN_NAME L"SimpleIndent"
#define PLUGIN_FILENAME L"SimpleIndent.dll"
#define PLUGIN_AUTHOR L"Vladimir Panteleev"
#define PLUGIN_VERSION MAKEFARVERSION(PLUGIN_MAJOR,PLUGIN_MINOR,0,0,VS_RELEASE)
